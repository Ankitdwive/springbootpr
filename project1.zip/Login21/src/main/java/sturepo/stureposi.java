package sturepo;

import org.springframework.stereotype.Repository;

import modelstu.stu;

@Repository
public interface stureposi  extends CrudRepository<stu, Long>{

}
