package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Login21Application {

	public static void main(String[] args) {
		SpringApplication.run(Login21Application.class, args);
		System.out.print("hello");		System.out.print("hello");
		System.out.print("hello");
		System.out.print("hello");
		System.out.print("hello");

	}

}
